from setuptools import setup

setup(
    name="dariko",
    version="0.1.0",
    packages=["dariko"],
    install_requires=[
        "pydantic>=2.0.0",
    ],
    python_requires=">=3.8",
)
